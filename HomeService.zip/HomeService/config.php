<?php

$host = "localhost";
$dbuser = "dew_app";
$dbpass = "1!Spider!1";
$dbname = "dew_homeservice";

?>