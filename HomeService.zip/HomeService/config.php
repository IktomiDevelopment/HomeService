<?php

$host = "localhost"; //probably just leave this one alone
$dbuser = "your_db_username";
$dbpass = "your_db_password";
$dbname = "your_db_name";

?>